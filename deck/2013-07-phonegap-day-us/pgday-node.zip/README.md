# PhoneGap Day

> PhoneGap Day Command-Line Title Slide

## Usage

    $ npm install
    $ sudo npm link .
    $ pgday
